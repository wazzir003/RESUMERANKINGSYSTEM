1. pip install -r requirements.txt
2. Replace GOOGLE_CLIENT_ID
3. add client_secret.json 
4. Replace MONGO_URI
5. Add assets folder
6. Finally flask run to start the server

#Check out this video for overall guide:
https://youtu.be/CphVOnBUkg4
